#include <stdio.h>

int main() {
	fprintf(stdout, "Hello world!");
	return(0);
}